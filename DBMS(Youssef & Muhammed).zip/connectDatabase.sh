#!/bin/bash
echo "hello connect...!"

if [ -d Databases ]
then
	read -p "Enter Database Name U want to Connect: " dbName
	if [ -d Databases/$dbName ]
	then 
		clear
		export $dbName
		echo "*********************** Table Options *************************"
		select option in "Display Tables" "Create Table" "Drop Table" "Data Manipulation" "Back To Main Menu"
		do
			case $REPLY in
			1) ./displayTables.sh $dbName;;
			2) ./createTable.sh $dbName;;
			3) ./dropTable.sh $dbName;;
			4) ./dataManipulation.sh $dbName;;
			5) ./index.sh
			esac
		done
	else 
		echo "No Such DataBase Exists...!"
	fi
fi
