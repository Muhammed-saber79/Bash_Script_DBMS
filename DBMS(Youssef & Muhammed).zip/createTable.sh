#!/bin/bash
echo "hello create table...!"

if [ -d Databases ]
then 
	clear
	if [ -d Databases/$1 ]
	then
		read -p "Enter Name of The Table U Want To Create: " tableName
		if [ -f Databases/$1/$tableName ]
		then 
			echo $1
			echo "This Table Already Exists...!"
		else
			touch Databases/$1/$tableName
			echo $1
			echo "Table Created Successfully."
			echo "/*===================================*/"
		fi
	fi
fi





