#!/bin/bash
echo "hello Create...!"


if [ -d Databases ]
then
	clear
	read -p "Enter Database Name U want to Create: " dbName
        if [ -f Databases/$dbName ]
        then 
                echo "This Database Already Exists...!"
        else
       		mkdir Databases/$dbName
		echo "Database Created Successfully."
		echo "Do You Want Connect To it?"
                select choice in "Y" "N"
                do 
                        case $REPLY in
                        Y) ./connectDatabase.sh;;
                        N) ./index.sh;;
                        esac
                done
        fi
fi
