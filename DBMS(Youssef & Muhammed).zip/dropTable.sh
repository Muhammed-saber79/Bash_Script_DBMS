#!/bin/bash
echo "hello drop table...!"

if [ -d Databases ]
then
	if [ -d Databases/$1 ]
	then 
        	read -p "Enter Table Name U want to Drop: " tableName
        	if [ -f Databases/$1/$tableName ]
        	then 
                	rm Databases/$1/$tableName
                	echo "Table Removed Successfully."
        	else
			echo "No Such Table Exists...!"
		fi
	fi
fi
