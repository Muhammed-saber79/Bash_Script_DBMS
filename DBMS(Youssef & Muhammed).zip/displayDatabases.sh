#!/bin/bash

if [ -d Databases ]
then
	if [ "$(ls -A Databases)" ]
        then 
                ls Databases
        else
                echo "No Databases Exist yet...!"
		echo "Do U Want To Create One?"
		select choice in "Y" "N"
		do 
			case $REPLY in
			Y) ./createDatabase.sh;;
			N) ./index.sh;;
			esac
		done
        fi
else
	mkdir Databases
	echo "No Databases Exist, yet...!"
fi
