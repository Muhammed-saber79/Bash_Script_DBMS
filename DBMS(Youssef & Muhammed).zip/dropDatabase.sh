#!/bin/bash
echo "hello drop...!"

if [ -d Databases ]
then
        read -p "Enter Database Name U want to Drop: " dbName
        if [ -d Databases/$dbName ]
        then 
                rm -r Databases/$dbName
                echo "Database Removed Successfully."
                select choice in "Enter R To Return To main Menu"
                do 
                        case $REPLY in
                        R) ./index.sh
			esac
		done
        fi
fi


