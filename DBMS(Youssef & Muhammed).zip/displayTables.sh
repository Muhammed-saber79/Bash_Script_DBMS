#!/bin/bash
echo "Hello Display..."

if [ -d Databases ]
then
        clear
        if [ -d Databases/$1 ]
        then 
       		if [ "$(ls -A Databases/$1)" ]
        	then 
                	ls Databases/$1
        	else
                	echo "No Tables Exist yet...!"
                	echo "Do U Want To Create One?"
                	select choice in "Y" "N"
                	do 
                        	case $REPLY in
                        	Y) ./createTable.sh;;
                        	N) ./connectDatabase.sh;;
                        	esac
                	done
        	fi
        fi
fi
